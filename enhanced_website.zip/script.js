document.getElementById("contact-form").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Thank you for your message! I'll get back to you soon.");
  this.reset();
});

document.getElementById("appointment-form").addEventListener("submit", function(e) {
  e.preventDefault();
  alert("Your appointment request has been submitted!");
  this.reset();
});
